# SalesEdge Frontend — Production Dockerfile
# Canonical copy lives at frontend/Dockerfile; this is a symlink-equivalent
# for the infra/ directory structure.
#
# Build: docker build -f infra/docker/frontend.Dockerfile -t salesedge-frontend ./frontend

# syntax=docker/dockerfile:1
# ─── Stage 1: build ───────────────────────────────────────────
FROM node:20-alpine AS builder

WORKDIR /app

COPY package.json package-lock.json* ./
RUN npm ci 2>/dev/null || npm install

COPY . .
RUN npm run build

# ─── Stage 2: nginx ───────────────────────────────────────────
FROM nginx:1.25-alpine

COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80

HEALTHCHECK --interval=30s --timeout=5s --start-period=10s --retries=3 \
    CMD wget -qO- http://127.0.0.1/ >/dev/null || exit 1

CMD ["nginx", "-g", "daemon off;"]
